'use strict';

/**
 * NODE — Tech Accessories storefront
 * Vanilla ES6+ module (IIFE), no external dependencies.
 */
(() => {
  // ---------------------------------------------------------------------
  // Data
  // ---------------------------------------------------------------------
  const PRODUCTS = Object.freeze([
    // Mobile Accessories
    { id: 'm1', cat: 'mobile', name: 'Braided USB-C Cable, 2m', spec: '100W PD · Nylon jacket', price: 14.99, icon: '⚡', stock: 'in' },
    { id: 'm2', cat: 'mobile', name: 'MagSafe-Compatible Wallet', spec: '3-card · Vegan leather', price: 24.00, icon: '💳', stock: 'in' },
    { id: 'm3', cat: 'mobile', name: '20W Wall Charger, Dual Port', spec: 'USB-C + USB-A', price: 19.50, icon: '🔌', stock: 'in' },
    { id: 'm4', cat: 'mobile', name: 'Clear Impact Case', spec: 'Drop-tested 8ft · iPhone/Galaxy', price: 16.00, icon: '📱', stock: 'low' },
    { id: 'm5', cat: 'mobile', name: 'Tempered Glass Screen Protector', spec: '2-pack · 9H hardness', price: 9.99, icon: '🛡️', stock: 'in' },
    { id: 'm6', cat: 'mobile', name: 'Pop-Grip Phone Stand', spec: 'Collapsible · Universal mount', price: 11.00, icon: '⭕', stock: 'in' },
    { id: 'm7', cat: 'mobile', name: '10,000mAh Power Bank', spec: '22.5W fast charge', price: 29.99, icon: '🔋', stock: 'in' },
    // Laptop Accessories
    { id: 'l1', cat: 'laptop', name: '7-in-1 USB-C Hub', spec: 'HDMI · SD · 3x USB-A · PD', price: 39.00, icon: '🔗', stock: 'in' },
    { id: 'l2', cat: 'laptop', name: 'Aluminum Laptop Stand', spec: 'Adjustable · Fits 11–17"', price: 34.50, icon: '💻', stock: 'in' },
    { id: 'l3', cat: 'laptop', name: '65W GaN Charger', spec: 'Compact · USB-C PD', price: 32.00, icon: '🔌', stock: 'low' },
    { id: 'l4', cat: 'laptop', name: 'Sleeve, 14-inch', spec: 'Water-resistant · Felt lining', price: 22.00, icon: '💼', stock: 'in' },
    { id: 'l5', cat: 'laptop', name: 'Wireless Mouse, Silent Click', spec: '2.4GHz + BT · 1600 DPI', price: 18.99, icon: '🖱️', stock: 'in' },
    { id: 'l6', cat: 'laptop', name: 'Compact Mechanical Keyboard', spec: '75% layout · Hot-swap', price: 64.00, icon: '⌨️', stock: 'in' },
    { id: 'l7', cat: 'laptop', name: 'Webcam Privacy Cover', spec: '3-pack · Ultra-slim', price: 6.50, icon: '🎥', stock: 'in' },
    // Earbuds & Headphones
    { id: 'a1', cat: 'audio', name: 'True Wireless Earbuds', spec: 'ANC · 30hr case battery', price: 59.00, icon: '🎧', stock: 'in' },
    { id: 'a2', cat: 'audio', name: 'Wired Earbuds, USB-C', spec: 'In-line mic · Flat cable', price: 12.99, icon: '🎵', stock: 'in' },
    { id: 'a3', cat: 'audio', name: 'Over-Ear Headphones', spec: '40mm drivers · Foldable', price: 49.00, icon: '🎧', stock: 'in' },
    { id: 'a4', cat: 'audio', name: 'Bluetooth ANC Headphones', spec: '35hr battery · Multipoint', price: 89.00, icon: '🎧', stock: 'low' },
    { id: 'a5', cat: 'audio', name: 'Sport Earbuds, Ear Hooks', spec: 'IPX7 · Wireless', price: 34.99, icon: '🏃', stock: 'in' },
    { id: 'a6', cat: 'audio', name: 'Wired Earbuds, 3.5mm', spec: 'Classic jack · In-line remote', price: 8.99, icon: '🎵', stock: 'in' },
    { id: 'a7', cat: 'audio', name: 'Earbud Silicone Tips Set', spec: 'S/M/L · 3 pairs', price: 5.99, icon: '⚪', stock: 'in' },
    // More
    { id: 'x1', cat: 'more', name: 'Desk Cable Organizer', spec: 'Clips + sleeve combo', price: 9.50, icon: '🧵', stock: 'in' },
    { id: 'x2', cat: 'more', name: 'Wireless Charging Pad', spec: '15W · Qi-certified', price: 21.00, icon: '🔵', stock: 'in' },
    { id: 'x3', cat: 'more', name: 'Portable Bluetooth Speaker', spec: 'IPX6 · 12hr playtime', price: 44.00, icon: '🔊', stock: 'in' },
    { id: 'x4', cat: 'more', name: 'Laptop-to-Phone Stand, Dual', spec: 'Foldable aluminum', price: 15.00, icon: '📐', stock: 'in' }
  ]);

  const CATEGORIES = Object.freeze([
    { key: 'mobile', title: 'Mobile Accessories' },
    { key: 'laptop', title: 'Laptop Accessories' },
    { key: 'audio', title: 'Earbuds & Headphones' },
    { key: 'more', title: 'More' }
  ]);

  const CONFIG = Object.freeze({
    FREE_SHIPPING_THRESHOLD: 50,
    SHIPPING_COST: 5.99,
    ADDED_FEEDBACK_MS: 900
  });

  const PRODUCTS_BY_ID = new Map(PRODUCTS.map(p => [p.id, p]));

  // ---------------------------------------------------------------------
  // State
  // ---------------------------------------------------------------------
  /** @type {Record<string, number>} product id -> quantity */
  let cart = {};
  let activeFilter = 'all';
  let lastFocusedElement = null;

  // ---------------------------------------------------------------------
  // DOM references (resolved once, checked for existence)
  // ---------------------------------------------------------------------
  const dom = {};
  const REQUIRED_IDS = [
    'catalog', 'rail', 'cartToggle', 'cartCount',
    'overlay', 'drawer', 'drawerClose', 'drawerItems', 'drawerFoot',
    'subtotal', 'shipping', 'grandTotal', 'checkoutBtn',
    'modalOverlay', 'modalBody', 'modalTitle', 'modalClose',
    'statProducts', 'statCategories'
  ];

  function cacheDom() {
    let ok = true;
    REQUIRED_IDS.forEach(id => {
      const el = document.getElementById(id);
      if (!el) {
        console.error(`[NODE] Missing required element #${id}. Some features may not work.`);
        ok = false;
      }
      dom[id] = el;
    });
    return ok;
  }

  // ---------------------------------------------------------------------
  // Utilities
  // ---------------------------------------------------------------------
  const currency = (n) => `$${n.toFixed(2)}`;

  /** Escapes text before it is interpolated into innerHTML. */
  function escapeHtml(str) {
    return String(str).replace(/[&<>"']/g, (ch) => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    }[ch]));
  }

  function findProduct(id) {
    const product = PRODUCTS_BY_ID.get(id);
    if (!product) console.warn(`[NODE] Unknown product id "${id}" ignored.`);
    return product;
  }

  // ---------------------------------------------------------------------
  // Catalog rendering
  // ---------------------------------------------------------------------
  function productCardHtml(p) {
    const stockTag = p.stock === 'low'
      ? '<span class="stock-tag low">Low stock</span>'
      : '<span class="stock-tag">In stock</span>';
    return `
      <li class="card">
        <div class="card-visual">
          ${stockTag}
          <span class="icon" aria-hidden="true">${p.icon}</span>
        </div>
        <p class="card-name">${escapeHtml(p.name)}</p>
        <p class="card-spec">${escapeHtml(p.spec)}</p>
        <div class="card-bottom">
          <span class="price">${currency(p.price)}</span>
          <button type="button" class="add-btn" data-id="${p.id}">
            <span class="add-btn-label">Add</span>
            <span class="visually-hidden"> ${escapeHtml(p.name)} to cart</span>
          </button>
        </div>
      </li>
    `;
  }

  function renderCatalog() {
    if (!dom.catalog) return;

    const cats = activeFilter === 'all'
      ? CATEGORIES
      : CATEGORIES.filter(c => c.key === activeFilter);

    const html = cats.map(cat => {
      const items = PRODUCTS.filter(p => p.cat === cat.key);
      return `
        <section class="cat-group" id="${cat.key}" aria-labelledby="${cat.key}-heading">
          <div class="cat-header">
            <h2 id="${cat.key}-heading">${escapeHtml(cat.title)}</h2>
            <span class="count mono">${items.length} item${items.length === 1 ? '' : 's'}</span>
          </div>
          <ul class="grid">
            ${items.map(productCardHtml).join('')}
          </ul>
        </section>
      `;
    }).join('');

    dom.catalog.innerHTML = html || '<p class="empty-cart">No products in this category yet.</p>';
  }

  // Event delegation: one listener handles every current and future .add-btn.
  function onCatalogClick(event) {
    const btn = event.target.closest('.add-btn');
    if (!btn || !dom.catalog.contains(btn)) return;

    const id = btn.dataset.id;
    const product = findProduct(id);
    if (!product) return;

    addToCart(id);

    const label = btn.querySelector('.add-btn-label');
    if (label) label.textContent = 'Added ✓';
    btn.classList.add('added');
    window.setTimeout(() => {
      if (label) label.textContent = 'Add';
      btn.classList.remove('added');
    }, CONFIG.ADDED_FEEDBACK_MS);
  }

  // ---------------------------------------------------------------------
  // Cart logic
  // ---------------------------------------------------------------------
  function addToCart(id) {
    if (!findProduct(id)) return;
    cart[id] = (cart[id] || 0) + 1;
    updateCartUI();
  }

  function changeQty(id, delta) {
    if (!cart[id]) return;
    cart[id] += delta;
    if (cart[id] <= 0) delete cart[id];
    updateCartUI();
  }

  function removeFromCart(id) {
    delete cart[id];
    updateCartUI();
  }

  function cartCount() {
    return Object.values(cart).reduce((a, b) => a + b, 0);
  }

  function cartSubtotal() {
    return Object.entries(cart).reduce((sum, [id, qty]) => {
      const p = findProduct(id);
      return p ? sum + p.price * qty : sum;
    }, 0);
  }

  function shippingFor(subtotal) {
    if (subtotal <= 0) return 0;
    return subtotal >= CONFIG.FREE_SHIPPING_THRESHOLD ? 0 : CONFIG.SHIPPING_COST;
  }

  function drawerItemHtml(id, qty, p) {
    return `
      <li class="drawer-item">
        <div class="thumb" aria-hidden="true">${p.icon}</div>
        <div class="drawer-item-info">
          <p class="name">${escapeHtml(p.name)}</p>
          <p class="price mono">${currency(p.price)}</p>
          <div class="qty-row">
            <button type="button" class="qty-btn" data-action="dec" data-id="${id}" aria-label="Decrease quantity of ${escapeHtml(p.name)}">−</button>
            <span class="qty-val" aria-live="polite">${qty}</span>
            <button type="button" class="qty-btn" data-action="inc" data-id="${id}" aria-label="Increase quantity of ${escapeHtml(p.name)}">+</button>
            <button type="button" class="remove-link" data-action="remove" data-id="${id}">Remove</button>
          </div>
        </div>
      </li>
    `;
  }

  function updateCartUI() {
    if (!dom.cartCount) return;

    const count = cartCount();
    dom.cartCount.textContent = String(count);

    const entries = Object.entries(cart).filter(([id]) => findProduct(id));

    if (entries.length === 0) {
      dom.drawerItems.innerHTML = '<p class="empty-cart">Your cart is empty.<br>Add something from the catalog.</p>';
      dom.drawerFoot.hidden = true;
      dom.checkoutBtn.disabled = true;
      return;
    }

    dom.drawerFoot.hidden = false;
    dom.checkoutBtn.disabled = false;

    dom.drawerItems.innerHTML = `<ul class="drawer-list">${
      entries.map(([id, qty]) => drawerItemHtml(id, qty, findProduct(id))).join('')
    }</ul>`;

    const subtotal = cartSubtotal();
    const shipping = shippingFor(subtotal);
    dom.subtotal.textContent = currency(subtotal);
    dom.shipping.textContent = shipping === 0 ? 'FREE' : currency(shipping);
    dom.grandTotal.textContent = currency(subtotal + shipping);
  }

  // Event delegation for quantity/remove controls inside the drawer.
  function onDrawerItemsClick(event) {
    const btn = event.target.closest('[data-action]');
    if (!btn) return;
    const { action, id } = btn.dataset;
    if (action === 'inc') changeQty(id, 1);
    else if (action === 'dec') changeQty(id, -1);
    else if (action === 'remove') removeFromCart(id);
  }

  // ---------------------------------------------------------------------
  // Category filter chips
  // ---------------------------------------------------------------------
  function onRailClick(event) {
    const chip = event.target.closest('.chip');
    if (!chip || !dom.rail.contains(chip)) return;

    dom.rail.querySelectorAll('.chip').forEach(c => {
      c.classList.remove('active');
      c.setAttribute('aria-pressed', 'false');
    });
    chip.classList.add('active');
    chip.setAttribute('aria-pressed', 'true');
    activeFilter = chip.dataset.filter;
    renderCatalog();
  }

  // ---------------------------------------------------------------------
  // Drawer open/close (with focus management)
  // ---------------------------------------------------------------------
  function openDrawer() {
    lastFocusedElement = document.activeElement;
    dom.overlay.classList.add('open');
    dom.drawer.classList.add('open');
    dom.drawer.setAttribute('aria-hidden', 'false');
    dom.overlay.setAttribute('aria-hidden', 'false');
    document.addEventListener('keydown', onDrawerKeydown);
    window.requestAnimationFrame(() => dom.drawerClose.focus());
  }

  function closeDrawer() {
    dom.overlay.classList.remove('open');
    dom.drawer.classList.remove('open');
    dom.drawer.setAttribute('aria-hidden', 'true');
    dom.overlay.setAttribute('aria-hidden', 'true');
    document.removeEventListener('keydown', onDrawerKeydown);
    if (lastFocusedElement) lastFocusedElement.focus();
  }

  function onDrawerKeydown(event) {
    if (event.key === 'Escape') {
      closeDrawer();
    } else if (event.key === 'Tab') {
      trapFocus(event, dom.drawer);
    }
  }

  function trapFocus(event, container) {
    const focusable = container.querySelectorAll(
      'button:not([disabled]), [href], input:not([disabled]), select, textarea, [tabindex]:not([tabindex="-1"])'
    );
    if (focusable.length === 0) return;
    const first = focusable[0];
    const last = focusable[focusable.length - 1];

    if (event.shiftKey && document.activeElement === first) {
      event.preventDefault();
      last.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault();
      first.focus();
    }
  }

  // ---------------------------------------------------------------------
  // Checkout modal
  // ---------------------------------------------------------------------
  function checkoutFormHtml(subtotal, shipping, total) {
    return `
      <div class="modal-summary">
        <div class="modal-summary-row"><span>Items (${cartCount()})</span><span>${currency(subtotal)}</span></div>
        <div class="modal-summary-row"><span>Shipping</span><span>${shipping === 0 ? 'FREE' : currency(shipping)}</span></div>
        <div class="modal-summary-row grand"><span>Total</span><span>${currency(total)}</span></div>
      </div>
      <form id="checkoutForm" novalidate>
        <div class="field-row">
          <div class="field"><label for="fname">First name</label><input type="text" id="fname" name="fname" autocomplete="given-name" required></div>
          <div class="field"><label for="lname">Last name</label><input type="text" id="lname" name="lname" autocomplete="family-name" required></div>
        </div>
        <div class="field"><label for="email">Email</label><input type="email" id="email" name="email" autocomplete="email" required></div>
        <div class="field"><label for="address">Shipping address</label><input type="text" id="address" name="address" autocomplete="street-address" required></div>
        <div class="field-row">
          <div class="field"><label for="city">City</label><input type="text" id="city" name="city" autocomplete="address-level2" required></div>
          <div class="field"><label for="zip">ZIP / Postal</label><input type="text" id="zip" name="zip" autocomplete="postal-code" required></div>
        </div>
        <div class="field">
          <label for="card">Card number</label>
          <input type="text" id="card" name="card" inputmode="numeric" autocomplete="cc-number"
                 placeholder="•••• •••• •••• ••••" pattern="[0-9\\s]{13,19}" maxlength="19" required>
        </div>
        <div class="field-row">
          <div class="field">
            <label for="exp">Expiry</label>
            <input type="text" id="exp" name="exp" inputmode="numeric" autocomplete="cc-exp"
                   placeholder="MM/YY" pattern="(0[1-9]|1[0-2])\\/[0-9]{2}" maxlength="5" required>
          </div>
          <div class="field">
            <label for="cvc">CVC</label>
            <input type="text" id="cvc" name="cvc" inputmode="numeric" autocomplete="cc-csc"
                   placeholder="•••" pattern="[0-9]{3,4}" maxlength="4" required>
          </div>
        </div>
        <button type="submit" class="place-order-btn">Place Order — ${currency(total)}</button>
      </form>
    `;
  }

  function openCheckout() {
    if (cartCount() === 0) return;

    dom.modalTitle.textContent = 'Checkout';
    const subtotal = cartSubtotal();
    const shipping = shippingFor(subtotal);
    const total = subtotal + shipping;

    dom.modalBody.innerHTML = checkoutFormHtml(subtotal, shipping, total);

    const form = document.getElementById('checkoutForm');
    form.addEventListener('submit', (event) => {
      event.preventDefault();
      if (!form.reportValidity()) return;
      showSuccess(total);
    });

    openModal();
  }

  function showSuccess(total) {
    const orderId = `ND-${Math.floor(100000 + Math.random() * 900000)}`;
    dom.modalTitle.textContent = 'Order Placed';
    dom.modalBody.innerHTML = `
      <div class="success-view">
        <div class="success-icon" aria-hidden="true">✓</div>
        <h3>Thanks — you're all set.</h3>
        <p>A confirmation has been sent to your email. Your order is being prepared for shipment.</p>
        <div class="order-id">Order ID: ${escapeHtml(orderId)}</div>
        <button type="button" class="continue-btn" id="continueBtn">Continue Browsing</button>
      </div>
    `;
    document.getElementById('continueBtn').addEventListener('click', () => {
      cart = {};
      updateCartUI();
      closeModal();
      closeDrawer();
    });
  }

  function openModal() {
    lastFocusedElement = document.activeElement;
    dom.modalOverlay.classList.add('open');
    dom.modalOverlay.setAttribute('aria-hidden', 'false');
    document.addEventListener('keydown', onModalKeydown);
    window.requestAnimationFrame(() => {
      const firstField = dom.modalBody.querySelector('input, button');
      if (firstField) firstField.focus();
    });
  }

  function closeModal() {
    dom.modalOverlay.classList.remove('open');
    dom.modalOverlay.setAttribute('aria-hidden', 'true');
    document.removeEventListener('keydown', onModalKeydown);
    if (lastFocusedElement) lastFocusedElement.focus();
  }

  function onModalKeydown(event) {
    if (event.key === 'Escape') {
      closeModal();
    } else if (event.key === 'Tab') {
      trapFocus(event, dom.modalOverlay.querySelector('.modal'));
    }
  }

  // ---------------------------------------------------------------------
  // Hero stats (computed, not hard-coded)
  // ---------------------------------------------------------------------
  function renderHeroStats() {
    if (dom.statProducts) dom.statProducts.textContent = String(PRODUCTS.length);
    if (dom.statCategories) dom.statCategories.textContent = String(CATEGORIES.length);
  }

  // ---------------------------------------------------------------------
  // Wire up event listeners (delegated where possible)
  // ---------------------------------------------------------------------
  function bindEvents() {
    dom.catalog.addEventListener('click', onCatalogClick);
    dom.rail.addEventListener('click', onRailClick);
    dom.drawerItems.addEventListener('click', onDrawerItemsClick);

    dom.cartToggle.addEventListener('click', openDrawer);
    dom.drawerClose.addEventListener('click', closeDrawer);
    dom.overlay.addEventListener('click', closeDrawer);

    dom.checkoutBtn.addEventListener('click', openCheckout);
    dom.modalClose.addEventListener('click', closeModal);
    dom.modalOverlay.addEventListener('click', (e) => {
      if (e.target === dom.modalOverlay) closeModal();
    });
  }

  // ---------------------------------------------------------------------
  // Init
  // ---------------------------------------------------------------------
  function init() {
    if (!cacheDom()) return; // Abort gracefully if the page markup is incomplete.
    renderHeroStats();
    renderCatalog();
    updateCartUI();
    bindEvents();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
